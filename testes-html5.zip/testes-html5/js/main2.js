$('.portfolio-items').isotope({
  // options
  itemSelector: '.portfolio-item',
  layoutMode: 'fitRows'
});
$(document).ready( function(e) {
e.preventDefault();
  $('.portfolio-items').isotope({
    itemSelector: '.portfolio-item',
    percentPosition: true,
    masonry: {
      columnWidth: '.portfolio-filter'
    }
  });

});

/*var $container = $('.portfolio-items').isotope('.fitRows');

//filter itens on a click
$('.portfolio-filter').on('click','a', function(e){
  e.preventDefault();
  var filterValue = $(this).attr('data-filter');
  $container.isotope({ filter: filterValue });

  $('.portfolio-filter li').removeClass('active');
  $(this).closest('li').addClass('active');
});

var $grid = $('.portfolio-items').isotope();


$grid.isotope({ filter: '.web' });

// filter .alkali OR .alkaline-earth items
$grid.isotope({ filter: '.ilustra' });

// filter .metal AND .transition items
$grid.isotope({ filter: '.foto' });

// show all items
$grid.isotope({ filter: '*' });*/
