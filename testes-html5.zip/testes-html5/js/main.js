// external js: isotope.pkgd.js, imagesloaded.pkgd.js

docReady( function() {

  var grid = document.querySelector('.grid');
  var iso;

  imagesLoaded( grid, function() {
    // init Isotope after all images have loaded
    iso = new Isotope( grid, {
      itemSelector: '.grid-item',
      percentPosition: true,
      masonry: {
        columnWidth: '.grid-sizer'
      }
    });
  });

});
